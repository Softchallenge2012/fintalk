# OnFile — v5 prototype code

- `OnFile Mockups v5.dc.html` — source. Template markup + `class Component` logic (screens, data, state). Needs `support.js` in the same folder; serve the folder over http (e.g. `npx serve .`) and open the file.
- `support.js` — runtime that renders the source file.
- `OnFile Prototype (standalone).html` — single self-contained build. Double-click to open; works offline.

All styling is inline. Colors follow the prototype tokens (brand #1F3B8F, ok #1E6B47, warn #8A5109, crit #A3242E). Interactive elements carry `data-event` attributes.
